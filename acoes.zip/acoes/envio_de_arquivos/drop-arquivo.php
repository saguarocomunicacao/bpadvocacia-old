<?php
include("../../include/inc/main.php");
include("../../include/inc/data.php");

$data = date("Y-m-d H:i:s");


$numeroUnicoGet = $_REQUEST["numeroUnico_upload_arquivo"];

if(is_dir("../../files/envio_de_arquivos_lista")) { 
	if(is_dir("../../files/envio_de_arquivos_lista/".$numeroUnicoGet."")) { 
	} else {
		criaPastaComCaminho("files/envio_de_arquivos_lista/","".$numeroUnicoGet."");
	}
} else {
	if(is_dir("../../files/envio_de_arquivos_lista/".$numeroUnicoGet."/")) { 
	} else {
		criaPastaComCaminho("files/","envio_de_arquivos_lista");
		criaPastaComCaminho("files/envio_de_arquivos_lista/","".$numeroUnicoGet."");
	}
}

$extensao = $_FILES['file']['name'];
$extensao = substr($extensao, -4);
if($extensao[0] == '.'){
	$extensao = substr($extensao, -3);
}
$extensao = strtolower($extensao);

if(trim($extensao)=="zip") {

	$caminhoUpload = "../../files/envio_de_arquivos_lista/".$numeroUnicoGet.""; 
	$file = $caminhoUpload ."/". basename($_FILES['file']['name']); 
	 
	if (move_uploaded_file($_FILES['file']['tmp_name'], $file)) { } else { }

	require_once("../../include/lib/pclzip.lib.php");

	$filezip = substr("".$_FILES['file']['name']."",0,-4);
	#$qtd_fotos = mysql_num_rows(mysql_query("SELECT * FROM envio_de_arquivos_galeria WHERE numeroUnico='".$numeroUnicoGet."'"));

	$archive = new PclZip("".$caminhoUpload."/".$_FILES['file']['name']."");
	if (($v_result_list = $archive->extract(PCLZIP_OPT_PATH, "".$caminhoUpload."",PCLZIP_OPT_REMOVE_PATH, "install/release")) == 0) {
		die("Error : ".$archive->errorInfo(true));
	}

	$narray = sizeof($v_result_list);
	$ordem = $qtd_fotos;
	for($i=0;$i < $narray; $i++) {

		$pos_recorte = strpos($v_result_list[$i]["stored_filename"], '-');
		$idprocessoGet = substr($v_result_list[$i]["stored_filename"],0,$pos_recorte);

		$parceiro_adv_processo = mysql_fetch_array(mysql_query("SELECT numeroUnico FROM parceiro_adv_processo WHERE id='".$idprocessoGet."'"));
		
		$ordem = $ordem + 1;
		$nome_sujo = $v_result_list[$i]["stored_filename"];
		$file = $v_result_list[$i]["stored_filename"];
		$file = str_replace("?","",utf8_decode($file));
		$file = preg_replace("/[][><}{)(:;,!?*%~^`&#@]/", "", $file);
		$file = preg_replace("/ /", "_", $file);
		rename("".$caminhoUpload."/".$nome_sujo."", "".$caminhoUpload."/".$file."");
		
		$data = date("Y-m-d H:i:s");
		$numeroUnicoGerado = geraCodReturn();
		$insert = mysql_query("INSERT INTO envio_de_arquivos_lista (criador,numeroUnico_pasta,numeroUnico,numeroUnico_pai,idprocesso,arquivo,data,dataModificacao) 
															VALUES 
														   ('".$sysusu['id']."','".$numeroUnicoGet."','".$numeroUnicoGerado."','".$parceiro_adv_processo['numeroUnico']."','".$idprocessoGet."','".$file."','".$data."','".$data."')");

		$parceiro_adv_processo_tipo = mysql_fetch_array(mysql_query("SELECT nome FROM parceiro_adv_processo_tipo WHERE id='19'"));
		$update = mysql_query("UPDATE parceiro_adv_processo SET idparceiro_adv_processo_tipo_txt='".$parceiro_adv_processo_tipo['nome']."',idparceiro_adv_processo_tipo='19' WHERE id='".$idprocessoGet."'");
	}

	unlink("".$caminhoUpload."/".$_FILES['file']['name']."");

} else {
	echo"<script>alert('O arquivo enviado não é do tipo ZIP')</script>";
}
?>
